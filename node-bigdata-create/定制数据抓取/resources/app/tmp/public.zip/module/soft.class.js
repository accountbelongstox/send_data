class SC{
    constructor(){

    }

    //检查是否升级
    checkUpdate(){
        let
            that = this,
            webData = that.load.json.webData,
            data = webData.software,
            supportWebHtml = data.updateURL,
            currentVersion = webData.base.version
        ;
        currentVersion = parseFloat(currentVersion);
        that.load.eles.currengVersionShow.html(currentVersion);
        (function checkUp(){
            that.load.module.web.Ajax(supportWebHtml,(data)=>{
                let
                    version = parseFloat(data.version),
                    files = data.files
                ;
                console.log(`update check ${version },${ currentVersion}`)
                if(version > currentVersion){
                    that.load.eles.softupdateInfo.html(`新版本升级! v${version}`);
                    that.load.module.console.success(`当前发现有新的更新, 请点右上方升级! 最新版本号 ${version} !`);
                    that.load.eles.version_li.show();
                    that.load.eles.version_li.find("a").attr('data-electron-args',files.join(`,`));
                }else{
/*                    setTimeout(()=>{
                        console.log(`timeOut check update!`);
                        checkUp();
                    },600000);*/
                }
            });
        })();
    }
}
module.exports = SC;