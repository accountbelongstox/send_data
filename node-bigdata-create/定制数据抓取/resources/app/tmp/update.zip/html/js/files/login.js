$(function() {


	//===== Form elements styling =====//
	
	$(".styled").uniform({ radioClass: 'choice' });

	
});

	
