class C{

	constructor(load){
	}

    isEmpty(){
        let
            that = this
        ;
        if(!that.load.option.csvData.length || that.load.option.csvData.length === 0){
            return true;
        }else{
            return false;
        }
    }

    initAdd(data=null){
        let
            that = this
        ;
        if(that.load.option.csvData.length === 0 && data){
            that.load.option.csvData.push(data);
        }
    }

    init(data=null){
        let
            that = this
        ;
        if(!that.load.option.csvData){
            that.load.option.csvData = [];
        }
        that.load.option.csvData.splice(0,that.load.option.csvData.length);
        if(data){
            that.load.option.csvData.push(data);
        }
    }

	addOne(...data){
		let
		that = this
		;
		if(data){
			let
                typeofDataFirst = typeof data[0],
            	typeofData = typeof data
			;
            if( typeofDataFirst === "object"){
                data = data[0];
            }else if(typeofData === "string"){
                data = data.split(/\,/);
            }
            data.forEach((dataItem,index)=>{
                dataItem = dataItem.toString();
                dataItem = dataItem.replace(/\,/ig,`，`);
                if(parseInt(dataItem) === parseInt(dataItem)){
                    dataItem = `="${dataItem}"`;
                }
                data[index] = dataItem;
            });
            data = data.join(`,`);
            that.load.option.csvData.push(data);
		}
	}

	//保存 CSV 文件
	save(filePath,content,callback,createTime = true){
		if(content instanceof Function){
			callback = content;
			content = null;
		}
		let
		that = this,
		filePathParse = that.load.node.path.parse(filePath)
		;
		filePath = filePath.replace(/\.csv$/i,``);
		if(createTime){
			filePath = filePath+'-'+that.load.module.tools.timeFormat("yyyy-mm-dd-hh-mm-ss");
		}
		filePath = filePath+`.csv`;
		if(!filePathParse.root){
            filePath = filePath.replace(/[\/\\\?\|\;\:\'\"\<\>\,]/ig,`-`);
			filePath = that.load.node.path.join(that.load.node.os.homedir(),`Desktop/`+filePath);
		}
		if(!content && (content = that.load.option.csvData.join(`\r\n`)) ){
	        content = that.load.node["iconv-lite"].encode(content, "gbk");
	        that.load.node.fs.writeFile(filePath,content,(err)=>{
	        	if(err){
	        		console.log(err);
	        	}
	        	if(callback){
	        		callback(filePath);
	        	}
	        });		
		}else{
        	if(callback){
        		callback(null);
        	}
		}
	}
}

module.exports = C;